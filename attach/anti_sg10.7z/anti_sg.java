/* 透かし除去ソフト「透かしを除去したったー」 Ver.1.0
 * 使い方：ソースとマスク画像を読み込み、透かし前後の色を2箇所指定するだけ
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.TransferHandler;

import com.sun.corba.se.spi.ior.TaggedProfileTemplate;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class anti_sg extends JFrame implements ActionListener{
	/* メンバ変数 */
	// 定数
	static final String kSoftName = "透かしを除去したったー";
	static final int kObjectWX = 80;	//オブジェクトサイズ(横)
	static final int kObjectWY = 24;	//オブジェクトサイズ(縦)
	static final int kObjectSpace = 10;	//オブジェクトサイズ(空白)
	static final int kPicColors = 2;	//選択できる色の数(現在→真実のペアで数える)
	// 変数
	//入力画像・マスク画像
	static JTextField text_path_source, text_path_mask;
	static File path_source, path_mask;
	static BufferedImage image_source, image_mask;
	//透かしについて
	int[] sg_rgb;
	double sg_alpha;
	boolean sg_flg;
	//その他
	static anti_sg window;	//メイン画面
	static JTextField[] text_color_before, text_color_after;	//現在・真実の色
	static JTextField text_sg_rgb, text_sg_alpha;				//透かしのRGB・アルファ値
	/* コンストラクタ */
	anti_sg(){
		// ウィンドウ設定
		setTitle(kSoftName);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setPreferredSize(new Dimension(position_x(4), position_y(6)));
		setResizable(false);
		setVisible(true);
		// オブジェクト設定
		JPanel panel = new JPanel();
		panel.setLayout(null);
		//ソース画像部分
		JLabel label_source = new JLabel("ソース画像");
			label_source.setBounds(position_x(0), position_y(0), size_x(1), size_y(1));
			panel.add(label_source);
		text_path_source = new JTextField();
			text_path_source.setBounds(position_x(1), position_y(0), size_x(2), size_y(1));
			text_path_source.setMargin(new Insets(0, 0, 0, 0));
			text_path_source.setEnabled(false);
			text_path_source.setTransferHandler(new DropFileHandler());
			panel.add(text_path_source);
		JButton button_browse_source = new JButton("参照...");
			button_browse_source.setBounds(position_x(3), position_y(0), size_x(1), size_y(1));
			button_browse_source.setMargin(new Insets(0, 0, 0, 0));
			button_browse_source.addActionListener(this);
			button_browse_source.setActionCommand("参照(ソース)");
			panel.add(button_browse_source);
		//マスク画像部分
		JLabel label_mask = new JLabel("マスク画像");
		label_mask.setBounds(position_x(0), position_y(1), size_x(1), size_y(1));
			panel.add(label_mask);
		text_path_mask = new JTextField();
			text_path_mask.setBounds(position_x(1), position_y(1), size_x(2), size_y(1));
			text_path_mask.setMargin(new Insets(0, 0, 0, 0));
			text_path_mask.setEnabled(false);
			text_path_mask.setTransferHandler(new DropFileHandler());
			panel.add(text_path_mask);
		JButton button_browse_mask = new JButton("参照...");
			button_browse_mask.setBounds(position_x(3), position_y(1), size_x(1), size_y(1));
			button_browse_mask.setMargin(new Insets(0, 0, 0, 0));
			button_browse_mask.addActionListener(this);
			button_browse_mask.setActionCommand("参照(マスク)");
			panel.add(button_browse_mask);
		//色選択部分
		text_color_before = new JTextField[kPicColors];
		text_color_after = new JTextField[kPicColors];
		for(int i = 0; i < kPicColors; ++i){
			// 今の色
			JLabel label1 = new JLabel("今の色" + (i + 1));
				label1.setBounds(position_x(0), position_y(i * 2 + 2), size_x(1), size_y(1));
				panel.add(label1);
			text_color_before[i] = new JTextField();
				text_color_before[i].setBounds(position_x(1), position_y(i * 2 + 2), size_x(1), size_y(1));
				text_color_before[i].setMargin(new Insets(0, 0, 0, 0));
				panel.add(text_color_before[i]);
			JButton button1 = new JButton("選択...");
				button1.setBounds(position_x(2), position_y(i * 2 + 2), size_x(1), size_y(1));
				button1.setMargin(new Insets(0, 0, 0, 0));
				button1.addActionListener(this);
				button1.setActionCommand("選択(今)-" + (i + 1));
				panel.add(button1);
			// 本当の色
			JLabel label2 = new JLabel("本当の色" + (i + 1));
				label2.setBounds(position_x(0), position_y(i * 2 + 3), size_x(1), size_y(1));
				panel.add(label2);
			text_color_after[i] = new JTextField();
				text_color_after[i].setBounds(position_x(1), position_y(i * 2 + 3), size_x(1), size_y(1));
				text_color_after[i].setMargin(new Insets(0, 0, 0, 0));
				panel.add(text_color_after[i]);
			JButton button2 = new JButton("選択...");
				button2.setBounds(position_x(2), position_y(i * 2 + 3), size_x(1), size_y(1));
				button2.setMargin(new Insets(0, 0, 0, 0));
				button2.addActionListener(this);
				button2.setActionCommand("選択(真)-" + (i + 1));
				panel.add(button2);
		}
		//透かし部分
		text_sg_rgb = new JTextField();
			text_sg_rgb.setBounds(position_x(3), position_y(2), size_x(1), size_y(1));
			text_sg_rgb.setMargin(new Insets(0, 0, 0, 0));
			text_sg_rgb.setEnabled(false);
			panel.add(text_sg_rgb);
		text_sg_alpha = new JTextField();
			text_sg_alpha.setBounds(position_x(3), position_y(3), size_x(1), size_y(1));
			text_sg_alpha.setMargin(new Insets(0, 0, 0, 0));
			text_sg_alpha.setEnabled(false);
			panel.add(text_sg_alpha);
		//保存部分
		JButton button_save = new JButton("保存");
			button_save.setBounds(position_x(3), position_y(5), size_x(1), size_y(1));
			button_save.setMargin(new Insets(0, 0, 0, 0));
			button_save.addActionListener(this);
			button_save.setActionCommand("保存");
			panel.add(button_save);
		getContentPane().add(panel, BorderLayout.CENTER);
		pack();
		/*text_path_source.setText("F:\\ソフトウェア\\マルチメディア\\画像\\・変換\\透かしを除去したったー\\sample.png");
		text_path_mask.setText("F:\\ソフトウェア\\マルチメディア\\画像\\・変換\\透かしを除去したったー\\mask.png");
		text_color_before[0].setText("A1C8DD");
		text_color_after[0].setText("FFEFE0");
		text_color_before[1].setText("988EAF");
		text_color_after[1].setText("EA6B76");*/
	}
	/* main関数 */
	public static void main(String[] args) {
		javax.swing.UIManager.put("swing.boldMetal", Boolean.FALSE); 
		window = new anti_sg();
	}
	/* オブジェクト用定数を計算する */
	static int position_x(int x){return kObjectSpace * (x + 1) + kObjectWX * x;}
	static int position_y(int y){return kObjectSpace * (y + 1) + kObjectWY * y;}
	static int size_x(int x){return kObjectSpace * (x - 1) + kObjectWX * x;}
	static int size_y(int y){return kObjectSpace * (y - 1) + kObjectWY * y;}
	/* 画像読み込み */
	boolean readImage(){
		try{
			image_source = ImageIO.read(new File(text_path_source.getText()));
			image_mask = ImageIO.read(new File(text_path_mask.getText()));
			return true;
		}catch(Exception error){
			JOptionPane.showMessageDialog(this, "読み込めない画像がありました！", kSoftName, JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	/* マスク画像のRGBおよび透過度の値を推測する */
	void calcMaskColor(){
		// 元の色、および本当の色のRGB値を読み込む
		int[] color_before = new int[kPicColors], color_after = new int[kPicColors];
		try{
			for(int i = 0; i < kPicColors; ++i){
				color_before[i] = Integer.parseInt(text_color_before[i].getText(),16) & 0xFFFFFF;
				color_after[i] = Integer.parseInt(text_color_after[i].getText(),16) & 0xFFFFFF;
			}
		}
		catch(Exception e){
			return;
		}
		// マスクの色合いを推測する
		// 本来の色がxで今の色がnでマスクがmとすると、
		// アルファ値がa(a=1で完全不透過)である際、
		// n=m*a+x*(1-a) となる。つまり、変形すると
		// n-x=(m-x)*a となる。つまり、
		// (n1-x1)/(m-x1)=(n2-x2)/(m-x2)から
		// m = (n1*x2-n2*x1)/(x2-x1-n2+n1) となる。
		sg_rgb = new int[3];	//R・G・B
		sg_alpha = 0.0;	//マスクの度合い
		sg_flg = false;
		for(int p = 0; p < 3; ++p){
			int x1 = (color_after[0] >> ((2 - p) * 8)) & 0xFF;
			int x2 = (color_after[1] >> ((2 - p) * 8)) & 0xFF;
			int n1 = (color_before[0] >> ((2 - p) * 8)) & 0xFF;
			int n2 = (color_before[1] >> ((2 - p) * 8)) & 0xFF;
			int diff = x2 - x1 - n2 + n1;
			if(x2 - x1 - n2 + n1 == 0){
				validate();
				JOptionPane.showMessageDialog(this, "マスクの値を計算できませんでした！", kSoftName, JOptionPane.ERROR_MESSAGE);
				return;
			}
			double m = 1.0 * (n1 * x2 - n2 * x1) / (x2 - x1 - n2 + n1);
			if(m - x1 == 0){
				validate();
				JOptionPane.showMessageDialog(this, "マスクの値を計算できませんでした！", kSoftName, JOptionPane.ERROR_MESSAGE);
				return;
			}			sg_alpha += 1.0 * (n1 - x1) / (m - x1);
			sg_rgb[p] = (int) (m + 0.5);
			if(sg_rgb[p] < 0) sg_rgb[p] = 0;
			if(sg_rgb[p] > 255) sg_rgb[p] = 255;
		}
		sg_alpha /= 3.0;
		if(sg_alpha < 0.0) sg_alpha = 0.0;
		if(sg_alpha > 1.0) sg_alpha = 1.0;
		// 結果を出力する
		text_sg_rgb.setText(String.format("%02X%02X%02X", sg_rgb[0], sg_rgb[1], sg_rgb[2]));
		text_sg_alpha.setText(String.format("%.3f",sg_alpha));
		sg_flg = true;
	}
	/* イベント処理用 */
	public void actionPerformed(ActionEvent event){
		// メインウィンドウの入力に対する処理
		String command_str = event.getActionCommand();
		switch(command_str){
		case "参照(ソース)":
			JFileChooser file_chooser1 = new JFileChooser();
			if (file_chooser1.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
				String file_name = file_chooser1.getSelectedFile().toString();
				text_path_source.setText(file_name);
				text_path_source.setToolTipText(file_name);
			}
			break;
		case "参照(マスク)":
			JFileChooser file_chooser2 = new JFileChooser();
			if (file_chooser2.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
				String file_name = file_chooser2.getSelectedFile().toString();
				text_path_mask.setText(file_name);
				text_path_mask.setToolTipText(file_name);
			}
			break;
		case "保存":
			// 元絵を修正し、保存する
			//とりあえず元絵をコピーする
			if(!sg_flg) break;
			if(!readImage()) break;
			int wx = image_source.getWidth(), wy = image_source.getHeight();
			if(wx != image_mask.getWidth() || wy != image_mask.getHeight()) break;
			BufferedImage image_output = new BufferedImage(wx, wy, image_source.getType());
			Graphics graphics = image_output.createGraphics();
			graphics.drawImage(image_source, 0, 0, null);
			//マスク画像を見ながらちまちまと修正を掛ける
			//本来の色がxで今の色がnでマスクがmとすると、
			//アルファ値がa(a=1で完全不透過)である際、
			//n=m*a+x*(1-a) となる。つまり、変形すると
			//x=(n-m*a)/(1-a)
			
			for(int x = 0; x < wx; ++x){
				for(int y = 0; y < wy; ++y){
					if((image_mask.getRGB(x, y) & 0xFFFFFF) != 0x000000) continue;
					int color = image_source.getRGB(x, y);
					int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
					int new_r = (int)((1.0 * r - sg_alpha * sg_rgb[0]) / (1.0 - sg_alpha) + 0.5);
					int new_g = (int)((1.0 * g - sg_alpha * sg_rgb[1]) / (1.0 - sg_alpha) + 0.5);
					int new_b = (int)((1.0 * b - sg_alpha * sg_rgb[2]) / (1.0 - sg_alpha) + 0.5);
					if(new_r < 0) new_r = 0; if(new_r > 255) new_r = 255;
					if(new_g < 0) new_g = 0; if(new_g > 255) new_g = 255;
					if(new_b < 0) new_b = 0; if(new_b > 255) new_b = 255;
					Color new_color = new Color(new_r,new_g,new_b);
					image_output.setRGB(x, y, new_color.getRGB());
				}
			}
			//結果をプレビューする
			JFrame pre_save = new JFrame();
			pre_save.setTitle("プレビュー");
			pre_save.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			pre_save.getContentPane().setPreferredSize(new Dimension(wx, wy));
			pre_save.setResizable(false);
			JPanel pre_panel = new PreviewPanel(image_output);
			pre_panel.setLayout(null);
			pre_save.getContentPane().add(pre_panel, BorderLayout.CENTER);
			pre_save.pack();
			pre_save.setVisible(true);
			//
			int option = JOptionPane.showConfirmDialog(this, "保存しますか？");
			if (option == JOptionPane.YES_OPTION){
				JFileChooser file_chooser3 = new JFileChooser();
				if (file_chooser3.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) break;
				File file_output = file_chooser3.getSelectedFile();
				try{
					ImageIO.write(image_output, "png", file_output);
				}
				catch(Exception error){
					JOptionPane.showMessageDialog(this, "画像が保存できませんでした！", kSoftName, JOptionPane.ERROR_MESSAGE);
				}
			}
			pre_save.setVisible(false);
			break;
		default:
			if(!command_str.substring(0, 2).equals("選択")) break;
			// 画像をとりあえず読み込む
			if(!readImage()) break;
			if(image_source.getHeight() != image_mask.getHeight() || image_source.getWidth() != image_mask.getWidth()) break;
			// 入力画像だけをプレビュー表示する
			int number = Integer.parseInt(command_str.substring(6)) - 1;
			boolean true_flg = (command_str.substring(3,4).equals("今") ? false : true);
			int width = image_source.getWidth(), height = image_source.getHeight();
			PreviewFrame preview = new PreviewFrame(number, true_flg);
			preview.setTitle("プレビュー");
			preview.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			preview.getContentPane().setPreferredSize(new Dimension(width, height));
			preview.setResizable(false);
			JPanel panel = new PreviewPanel(image_source);
			panel.setLayout(null);
			preview.getContentPane().add(panel, BorderLayout.CENTER);
			preview.pack();
			break;
		}
	}
	/* ファイルドロップ時の設定 */
	class DropFileHandler extends TransferHandler{
		@Override
		public boolean canImport(TransferSupport support){
			// ドロップされていない場合は受け取らない
			if(!support.isDrop()) return false;
			// ドロップされたものがファイルではない場合は受け取らない
			if(!support.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) return false;
			return true;
		}
		@Override
		@SuppressWarnings("unchecked")
		public boolean importData(TransferSupport support){
			// 受け取っていいものか確認する
			if(!canImport(support)) return false;
			// ドロップ処理
			Transferable transferable = support.getTransferable();
			JTextField text_field = (JTextField)support.getComponent();
			try{
				// ファイルを受け取る
				List<File> files = (List<File>)transferable.getTransferData(DataFlavor.javaFileListFlavor);
				// 表示する
				text_field.setText(files.get(0).toString());
				text_field.setToolTipText(files.get(0).toString());
			}catch(Exception error){
				error.printStackTrace();
			}
			return true;
		}
	}
	/* プレビュー用ウィンドウ */
	class PreviewFrame extends JFrame implements MouseListener{
		private int number_;	//選択番号
		private boolean true_flg_;	//「本当の色」の方ならtrue
		private int offset_x_, offset_y_;	//枠線のオフセット
		public PreviewFrame(int number, boolean true_flg){
			number_ = number;
			true_flg_ = true_flg;
			setVisible(true);
			Insets insets = getInsets();
			offset_x_ = insets.left;
			offset_y_ = insets.top;
			addMouseListener(this);
		}
		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mousePressed(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
		public void mouseClicked(MouseEvent e){
			Point point = e.getPoint();
			int x = point.x - offset_x_, y = point.y - offset_y_;
			if(((image_mask.getRGB(x, y) & 0xFFFFFF) == 0x000000) != true_flg_){
				// 現在の色＆マスクの黒部分 or 本当の色＆マスクの白部分
				String temp = Integer.toHexString(image_source.getRGB(x, y) & 0xFFFFFF).toUpperCase();
				if(true_flg_){
					// 本当の色＆マスクの白部分
					text_color_after[number_].setText(temp);
					text_color_after[number_].setToolTipText(temp);
				}else{
					// 現在の色＆マスクの黒部分
					text_color_before[number_].setText(temp);
					text_color_before[number_].setToolTipText(temp);
				}
				calcMaskColor();
			}
			this.setVisible(false);
		}
	}
	class PreviewPanel extends JPanel {
		private BufferedImage image_;
		public PreviewPanel(BufferedImage image) {
			image_ = image;
		}
		@Override
	    public void paintComponent(Graphics g) {
			Graphics2D g2D = (Graphics2D) g;
			g2D.drawImage(image_,null,this);
		}
	}
}
